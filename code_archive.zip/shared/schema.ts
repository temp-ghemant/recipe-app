import { pgTable, text, serial, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  isAdmin: boolean("is_admin").default(false),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  isAdmin: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const ingredients = pgTable("ingredients", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  category: text("category").notNull(),
  imageUrl: text("image_url"),
  isPopular: boolean("is_popular").default(false),
});

export const insertIngredientSchema = createInsertSchema(ingredients).pick({
  name: true,
  category: true,
  imageUrl: true,
  isPopular: true,
});

export type InsertIngredient = z.infer<typeof insertIngredientSchema>;
export type Ingredient = typeof ingredients.$inferSelect;

export const recipes = pgTable("recipes", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url"),
  prepTime: integer("prep_time").notNull(), // in minutes
  calories: integer("calories"),
  servings: integer("servings"),
  cuisine: text("cuisine"),
  diet: text("diet"),
  difficulty: text("difficulty"),
  instructions: text("instructions").notNull(),
  ingredients: jsonb("ingredients").notNull().$type<Array<{id: number, name: string, amount: string}>>(),
  rating: integer("rating").default(0), // out of 5
  reviewCount: integer("review_count").default(0),
  authorId: integer("author_id").references(() => users.id),
  authorName: text("author_name").notNull(),
  authorAvatar: text("author_avatar"),
});

export const insertRecipeSchema = createInsertSchema(recipes).omit({
  id: true,
  rating: true,
  reviewCount: true,
});

export type InsertRecipe = z.infer<typeof insertRecipeSchema>;
export type Recipe = typeof recipes.$inferSelect;

export const recipeIngredients = pgTable("recipe_ingredients", {
  id: serial("id").primaryKey(),
  recipeId: integer("recipe_id").references(() => recipes.id).notNull(),
  ingredientId: integer("ingredient_id").references(() => ingredients.id).notNull(),
  amount: text("amount").notNull(),
});

export const insertRecipeIngredientSchema = createInsertSchema(recipeIngredients).omit({
  id: true,
});

export type InsertRecipeIngredient = z.infer<typeof insertRecipeIngredientSchema>;
export type RecipeIngredient = typeof recipeIngredients.$inferSelect;
