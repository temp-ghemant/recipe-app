import { users, type User, type InsertUser, type Ingredient, type InsertIngredient, ingredients, type Recipe, type InsertRecipe, recipes, type RecipeIngredient, type InsertRecipeIngredient, recipeIngredients } from "@shared/schema";
import { db, client } from "./db";
import { eq, ilike, inArray, and } from "drizzle-orm";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Ingredient methods
  getIngredients(): Promise<Ingredient[]>;
  getIngredientsByCategory(category: string): Promise<Ingredient[]>;
  getPopularIngredients(): Promise<Ingredient[]>;
  getIngredientById(id: number): Promise<Ingredient | undefined>;
  searchIngredients(query: string): Promise<Ingredient[]>;
  createIngredient(ingredient: InsertIngredient): Promise<Ingredient>;
  
  // Recipe methods
  getRecipes(): Promise<Recipe[]>;
  getRecipeById(id: number): Promise<Recipe | undefined>;
  searchRecipes(query: string): Promise<Recipe[]>;
  getRecipesByIngredients(ingredientIds: number[]): Promise<Recipe[]>;
  createRecipe(recipe: InsertRecipe): Promise<Recipe>;
  
  // Recipe-Ingredient relations
  getRecipeIngredients(recipeId: number): Promise<RecipeIngredient[]>;
  createRecipeIngredient(recipeIngredient: InsertRecipeIngredient): Promise<RecipeIngredient>;

  // Session store
  sessionStore: session.Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // 1 day in ms
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  
  // Ingredient methods
  async getIngredients(): Promise<Ingredient[]> {
    return db.select().from(ingredients);
  }
  
  async getIngredientsByCategory(category: string): Promise<Ingredient[]> {
    return db.select().from(ingredients).where(eq(ingredients.category, category));
  }
  
  async getPopularIngredients(): Promise<Ingredient[]> {
    return db.select().from(ingredients).where(eq(ingredients.isPopular, true));
  }
  
  async getIngredientById(id: number): Promise<Ingredient | undefined> {
    const [ingredient] = await db.select().from(ingredients).where(eq(ingredients.id, id));
    return ingredient;
  }
  
  async searchIngredients(query: string): Promise<Ingredient[]> {
    if (!query) return this.getIngredients();
    return db.select().from(ingredients).where(ilike(ingredients.name, `%${query}%`));
  }
  
  async createIngredient(ingredient: InsertIngredient): Promise<Ingredient> {
    const [newIngredient] = await db.insert(ingredients).values(ingredient).returning();
    return newIngredient;
  }
  
  // Recipe methods
  async getRecipes(): Promise<Recipe[]> {
    return db.select().from(recipes);
  }
  
  async getRecipeById(id: number): Promise<Recipe | undefined> {
    const [recipe] = await db.select().from(recipes).where(eq(recipes.id, id));
    return recipe;
  }
  
  async searchRecipes(query: string): Promise<Recipe[]> {
    if (!query) return this.getRecipes();
    
    return db.select().from(recipes).where(
      and(
        ilike(recipes.title, `%${query}%`),
        ilike(recipes.description, `%${query}%`)
      )
    );
  }
  
  async getRecipesByIngredients(ingredientIds: number[]): Promise<Recipe[]> {
    if (ingredientIds.length === 0) return this.getRecipes();
    
    // Get all recipe IDs that have these ingredients
    const relations = await db
      .select()
      .from(recipeIngredients)
      .where(inArray(recipeIngredients.ingredientId, ingredientIds));
    
    // Extract unique recipe IDs
    const uniqueRecipeIds = new Set(relations.map(rel => rel.recipeId));
    const recipeIds = Array.from(uniqueRecipeIds);
    
    if (recipeIds.length === 0) return [];
    
    // Get recipes with those IDs
    return db
      .select()
      .from(recipes)
      .where(inArray(recipes.id, recipeIds));
  }
  
  async createRecipe(recipe: InsertRecipe): Promise<Recipe> {
    const [newRecipe] = await db.insert(recipes).values(recipe).returning();
    return newRecipe;
  }
  
  // Recipe-Ingredient relations
  async getRecipeIngredients(recipeId: number): Promise<RecipeIngredient[]> {
    return db
      .select()
      .from(recipeIngredients)
      .where(eq(recipeIngredients.recipeId, recipeId));
  }
  
  async createRecipeIngredient(recipeIngredient: InsertRecipeIngredient): Promise<RecipeIngredient> {
    const [relation] = await db
      .insert(recipeIngredients)
      .values(recipeIngredient)
      .returning();
    return relation;
  }
}

export const storage = new DatabaseStorage();