import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { setupAuth, isAuthenticated, isAdmin } from "./auth";
import { insertIngredientSchema, insertRecipeSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication
  setupAuth(app);
  
  // Define API routes with /api prefix
  
  // Get all ingredients
  app.get("/api/ingredients", async (req, res) => {
    try {
      const ingredients = await storage.getIngredients();
      res.json(ingredients);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch ingredients" });
    }
  });
  
  // Get popular ingredients
  app.get("/api/ingredients/popular", async (req, res) => {
    try {
      const popularIngredients = await storage.getPopularIngredients();
      res.json(popularIngredients);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch popular ingredients" });
    }
  });
  
  // Get ingredients by category
  app.get("/api/ingredients/category/:category", async (req, res) => {
    try {
      const { category } = req.params;
      const ingredients = await storage.getIngredientsByCategory(category);
      res.json(ingredients);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch ingredients by category" });
    }
  });
  
  // Search ingredients
  app.get("/api/ingredients/search", async (req, res) => {
    try {
      const query = req.query.q as string || "";
      const ingredients = await storage.searchIngredients(query);
      res.json(ingredients);
    } catch (error) {
      res.status(500).json({ message: "Failed to search ingredients" });
    }
  });
  
  // Get all recipes
  app.get("/api/recipes", async (req, res) => {
    try {
      const recipes = await storage.getRecipes();
      res.json(recipes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recipes" });
    }
  });
  
  // Get recipe by ID
  app.get("/api/recipes/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid recipe ID" });
      }
      
      const recipe = await storage.getRecipeById(id);
      if (!recipe) {
        return res.status(404).json({ message: "Recipe not found" });
      }
      
      res.json(recipe);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recipe" });
    }
  });
  
  // Search recipes
  app.get("/api/recipes/search", async (req, res) => {
    try {
      const query = req.query.q as string || "";
      const recipes = await storage.searchRecipes(query);
      res.json(recipes);
    } catch (error) {
      res.status(500).json({ message: "Failed to search recipes" });
    }
  });
  
  // Get recipes by ingredient IDs
  app.get("/api/recipes/by-ingredients", async (req, res) => {
    try {
      let ingredientIds: number[] = [];
      
      if (req.query.ids) {
        // Parse comma-separated ingredient IDs
        const ids = (req.query.ids as string).split(",");
        ingredientIds = ids.map(id => parseInt(id)).filter(id => !isNaN(id));
      }
      
      const recipes = await storage.getRecipesByIngredients(ingredientIds);
      res.json(recipes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recipes by ingredients" });
    }
  });
  
  // Admin routes
  // Create a new ingredient (admin only)
  app.post("/api/admin/ingredients", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const validationResult = insertIngredientSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Invalid ingredient data", 
          errors: validationResult.error.errors 
        });
      }
      
      const ingredient = await storage.createIngredient(validationResult.data);
      res.status(201).json(ingredient);
    } catch (error) {
      res.status(500).json({ message: "Failed to create ingredient" });
    }
  });
  
  // Create a new recipe (admin only)
  app.post("/api/admin/recipes", isAuthenticated, isAdmin, async (req, res) => {
    try {
      // Extract ingredients from body before validation
      const { ingredients, ...recipeData } = req.body;
      
      const validationResult = insertRecipeSchema.safeParse(recipeData);
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Invalid recipe data", 
          errors: validationResult.error.errors 
        });
      }
      
      // First create the recipe
      const recipe = await storage.createRecipe(validationResult.data);
      
      // Then add all the ingredients
      if (ingredients && Array.isArray(ingredients)) {
        for (const ingredient of ingredients) {
          await storage.createRecipeIngredient({
            recipeId: recipe.id,
            ingredientId: ingredient.id,
            amount: ingredient.amount
          });
        }
      }
      
      res.status(201).json(recipe);
    } catch (error) {
      console.error("Failed to create recipe:", error);
      res.status(500).json({ message: "Failed to create recipe" });
    }
  });

  // Original recipe create route without admin check
  app.post("/api/recipes", async (req, res) => {
    try {
      const recipeData = req.body;
      const recipe = await storage.createRecipe(recipeData);
      res.status(201).json(recipe);
    } catch (error) {
      res.status(500).json({ message: "Failed to create recipe" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
