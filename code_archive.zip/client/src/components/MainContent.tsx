import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { useQuery } from "@tanstack/react-query";
import { Search, X } from "lucide-react";
import RecipeCard from "@/components/RecipeCard";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface MainContentProps {
  selectedIngredients: number[];
  onClearIngredient: (id: number) => void;
  onClearAllIngredients: () => void;
}

interface Ingredient {
  id: number;
  name: string;
  category: string;
  isPopular: boolean;
  imageUrl?: string;
}

export default function MainContent({
  selectedIngredients,
  onClearIngredient,
  onClearAllIngredients
}: MainContentProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("popular");
  const [selectedIngredientNames, setSelectedIngredientNames] = useState<{id: number, name: string}[]>([]);
  
  // Fetch all ingredients to get names
  const { data: allIngredients } = useQuery({
    queryKey: ["/api/ingredients"],
  });
  
  // Fetch recipes filtered by selected ingredients
  const { data: recipes, isLoading: isLoadingRecipes } = useQuery({
    queryKey: ["/api/recipes/by-ingredients", selectedIngredients.length === 0 ? "all" : selectedIngredients.join(",")],
    queryFn: async () => {
      if (selectedIngredients.length === 0) {
        const res = await fetch("/api/recipes");
        if (!res.ok) throw new Error("Failed to fetch recipes");
        return res.json();
      } else {
        const res = await fetch(`/api/recipes/by-ingredients?ids=${selectedIngredients.join(",")}`);
        if (!res.ok) throw new Error("Failed to fetch recipes by ingredients");
        return res.json();
      }
    }
  });
  
  // Update selected ingredient names whenever selectedIngredients changes
  useEffect(() => {
    if (allIngredients && selectedIngredients.length > 0) {
      const names = selectedIngredients.map(id => {
        const ingredient = allIngredients.find((ing: Ingredient) => ing.id === id);
        return { id, name: ingredient ? ingredient.name : `Ingredient ${id}` };
      });
      setSelectedIngredientNames(names);
    } else {
      setSelectedIngredientNames([]);
    }
  }, [selectedIngredients, allIngredients]);
  
  // Filter and sort recipes
  const filteredAndSortedRecipes = recipes && recipes.length > 0
    ? recipes
      .filter((recipe: any) => 
        searchQuery === "" || 
        recipe.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        recipe.cuisine?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        recipe.diet?.toLowerCase().includes(searchQuery.toLowerCase())
      )
      .sort((a: any, b: any) => {
        if (sortBy === "popular") return b.rating - a.rating;
        if (sortBy === "newest") return b.id - a.id;
        if (sortBy === "prepTime") return a.prepTime - b.prepTime;
        return 0;
      })
    : [];
  
  return (
    <div className="md:ml-64 w-full md:w-[calc(100%-16rem)] pb-24">
      {/* Recipe Search Section */}
      <div className="bg-white px-4 py-6 shadow-sm">
        <div className="container mx-auto">
          <div className="mb-6">
            <h2 className="font-semibold text-2xl mb-2">Find a Recipe</h2>
            <p className="text-neutral-600">Discover recipes based on the ingredients you have!</p>
          </div>
          
          <div className="relative">
            <Search className="absolute left-4 top-4 h-5 w-5 text-neutral-500" />
            <Input
              type="text"
              placeholder="Search recipes, cuisine types, or cooking methods..."
              className="w-full pl-12 pr-4 py-6 text-base"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          {/* Selected Ingredients Filter */}
          {selectedIngredientNames.length > 0 && (
            <div className="mt-4 flex items-center flex-wrap gap-2">
              <span className="text-sm text-neutral-600 font-medium">Filtering by:</span>
              {selectedIngredientNames.map(ing => (
                <div 
                  key={ing.id}
                  className="px-3 py-1 border border-secondary text-secondary bg-secondary/20 rounded-full text-sm cursor-pointer transition-colors flex items-center gap-1"
                >
                  {ing.name}
                  <X
                    className="h-3 w-3"
                    onClick={() => onClearIngredient(ing.id)}
                  />
                </div>
              ))}
              <Button
                variant="link"
                className="text-sm text-accent hover:text-accent/80 font-medium p-0 h-auto"
                onClick={onClearAllIngredients}
              >
                Clear All
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Recipe Results Section */}
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="font-semibold text-xl">
            {selectedIngredients.length > 0 ? "Matching Recipes" : "Recommended Recipes"}
          </h2>
          <div className="flex items-center gap-2">
            <span className="text-sm text-neutral-600">Sort by:</span>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-[160px]">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="popular">Most Popular</SelectItem>
                <SelectItem value="newest">Newest</SelectItem>
                <SelectItem value="prepTime">Preparation Time</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Recipe Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {isLoadingRecipes ? (
            // Show skeleton loaders while loading
            Array(6).fill(0).map((_, i) => (
              <div key={i} className="bg-white rounded-lg overflow-hidden shadow-sm">
                <Skeleton className="w-full h-48" />
                <div className="p-4">
                  <Skeleton className="h-6 w-3/4 mb-3" />
                  <Skeleton className="h-4 w-1/2 mb-3" />
                  <div className="flex justify-between mb-3">
                    <Skeleton className="h-4 w-1/4" />
                    <Skeleton className="h-4 w-1/4" />
                    <Skeleton className="h-4 w-1/4" />
                  </div>
                  <div className="flex gap-1 mb-4">
                    <Skeleton className="h-5 w-16 rounded-full" />
                    <Skeleton className="h-5 w-20 rounded-full" />
                    <Skeleton className="h-5 w-14 rounded-full" />
                  </div>
                  <Skeleton className="h-9 w-full rounded-md" />
                </div>
              </div>
            ))
          ) : filteredAndSortedRecipes.length === 0 ? (
            <div className="col-span-3 py-12 text-center">
              <h3 className="text-xl font-semibold text-neutral-700 mb-2">No recipes found</h3>
              <p className="text-neutral-600">
                {searchQuery ? 
                  "Try adjusting your search terms or filters." : 
                  "Try selecting different ingredients or clearing some filters."
                }
              </p>
            </div>
          ) : (
            filteredAndSortedRecipes.map((recipe: any) => (
              <RecipeCard key={recipe.id} recipe={recipe} />
            ))
          )}
        </div>

        {/* Pagination - implement if needed */}
        {filteredAndSortedRecipes.length > 0 && (
          <div className="mt-10 flex justify-center">
            <div className="flex items-center space-x-1">
              <Button variant="outline" size="icon" className="h-9 w-9">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <polyline points="15 18 9 12 15 6" />
                </svg>
              </Button>
              <Button variant="outline" className="bg-primary text-white">1</Button>
              <Button variant="outline">2</Button>
              <Button variant="outline">3</Button>
              <Button variant="outline">4</Button>
              <Button variant="outline">5</Button>
              <Button variant="outline" size="icon" className="h-9 w-9">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <polyline points="9 18 15 12 9 6" />
                </svg>
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
