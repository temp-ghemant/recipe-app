import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { useQuery } from "@tanstack/react-query";
import { Search } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface Ingredient {
  id: number;
  name: string;
  category: string;
  isPopular: boolean;
  imageUrl?: string;
}

interface IngredientCategory {
  name: string;
  ingredients: Ingredient[];
  isOpen: boolean;
}

interface IngredientSidebarProps {
  selectedIngredients: number[];
  onIngredientToggle: (id: number) => void;
}

export default function IngredientSidebar({
  selectedIngredients,
  onIngredientToggle
}: IngredientSidebarProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [categories, setCategories] = useState<IngredientCategory[]>([]);
  const [filteredCategories, setFilteredCategories] = useState<IngredientCategory[]>([]);

  // Fetch all ingredients
  const { data: allIngredients, isLoading: isLoadingIngredients } = useQuery({
    queryKey: ["/api/ingredients"],
  });

  // Fetch popular ingredients
  const { data: popularIngredients, isLoading: isLoadingPopular } = useQuery({
    queryKey: ["/api/ingredients/popular"],
  });

  // Group ingredients by category
  useEffect(() => {
    if (allIngredients) {
      const categoriesMap: Record<string, Ingredient[]> = {};
      
      allIngredients.forEach((ingredient: Ingredient) => {
        if (!categoriesMap[ingredient.category]) {
          categoriesMap[ingredient.category] = [];
        }
        categoriesMap[ingredient.category].push(ingredient);
      });

      const categoriesArray = Object.entries(categoriesMap).map(([name, ingredients]) => ({
        name,
        ingredients,
        isOpen: true
      }));

      setCategories(categoriesArray);
      setFilteredCategories(categoriesArray);
    }
  }, [allIngredients]);

  // Filter ingredients based on search query
  useEffect(() => {
    if (searchQuery.trim() === "") {
      setFilteredCategories(categories);
      return;
    }

    const lowercaseQuery = searchQuery.toLowerCase();
    const filtered = categories.map(category => {
      const filteredIngredients = category.ingredients.filter(
        ingredient => ingredient.name.toLowerCase().includes(lowercaseQuery)
      );
      return {
        ...category,
        ingredients: filteredIngredients
      };
    }).filter(category => category.ingredients.length > 0);

    setFilteredCategories(filtered);
  }, [searchQuery, categories]);

  // Toggle category expansion
  const toggleCategory = (categoryName: string) => {
    setCategories(
      categories.map(category => 
        category.name === categoryName 
          ? { ...category, isOpen: !category.isOpen } 
          : category
      )
    );
    setFilteredCategories(
      filteredCategories.map(category => 
        category.name === categoryName 
          ? { ...category, isOpen: !category.isOpen } 
          : category
      )
    );
  };

  // Handle ingredient tag click
  const handleTagClick = (id: number) => {
    onIngredientToggle(id);
  };

  return (
    <aside className="hidden md:block w-64 bg-white shadow-sm fixed h-full overflow-y-auto pt-6 pb-20 z-20">
      <div className="px-4">
        <h2 className="font-semibold text-lg mb-4">Ingredients</h2>
        
        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-3 h-4 w-4 text-neutral-500" />
          <Input 
            type="text" 
            placeholder="Search ingredients..." 
            className="w-full pl-10 pr-4 py-2"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
          />
        </div>

        {/* Popular Ingredients Tags */}
        <div className="mb-6">
          <h3 className="font-medium text-sm text-neutral-600 mb-2">POPULAR</h3>
          <div className="flex flex-wrap gap-2">
            {isLoadingPopular ? (
              Array(6).fill(0).map((_, i) => (
                <Skeleton key={i} className="h-7 w-20 rounded-full" />
              ))
            ) : (
              popularIngredients?.map((ingredient: Ingredient) => (
                <span 
                  key={ingredient.id}
                  className={`px-3 py-1 border rounded-full text-sm cursor-pointer transition-colors ${
                    selectedIngredients.includes(ingredient.id)
                      ? "bg-secondary/20 border-secondary text-secondary"
                      : "bg-neutral-100 border-neutral-300 hover:bg-neutral-200"
                  }`}
                  onClick={() => handleTagClick(ingredient.id)}
                >
                  {ingredient.name}
                </span>
              ))
            )}
          </div>
        </div>

        {/* Ingredient Categories */}
        <div className="space-y-4">
          {isLoadingIngredients ? (
            Array(4).fill(0).map((_, i) => (
              <div key={i} className="space-y-2">
                <Skeleton className="h-5 w-32 mb-2" />
                {Array(4).fill(0).map((_, j) => (
                  <Skeleton key={j} className="h-5 w-full" />
                ))}
              </div>
            ))
          ) : (
            filteredCategories.map(category => (
              <div key={category.name}>
                <h3 
                  className="font-medium text-sm text-neutral-600 mb-2 flex justify-between items-center cursor-pointer"
                  onClick={() => toggleCategory(category.name)}
                >
                  <span>{category.name.toUpperCase()}</span>
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    width="24" 
                    height="24" 
                    viewBox="0 0 24 24" 
                    fill="none" 
                    stroke="currentColor" 
                    strokeWidth="2" 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                    className={`h-4 w-4 transition-transform ${category.isOpen ? 'rotate-180' : ''}`}
                  >
                    <polyline points="6 9 12 15 18 9"></polyline>
                  </svg>
                </h3>
                {category.isOpen && (
                  <div className="space-y-2">
                    {category.ingredients.map(ingredient => (
                      <div key={ingredient.id} className="flex items-center">
                        <Checkbox 
                          id={`ingredient-${ingredient.id}`} 
                          className="mr-2 text-primary"
                          checked={selectedIngredients.includes(ingredient.id)}
                          onCheckedChange={() => onIngredientToggle(ingredient.id)}
                        />
                        <label 
                          htmlFor={`ingredient-${ingredient.id}`} 
                          className="text-sm text-neutral-700 cursor-pointer"
                        >
                          {ingredient.name}
                        </label>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </aside>
  );
}
