import { Heart } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";

interface Recipe {
  id: number;
  title: string;
  description: string;
  imageUrl: string;
  prepTime: number;
  calories: number;
  servings: number;
  cuisine: string;
  diet: string;
  difficulty: string;
  authorId: number;
  authorName: string;
  authorAvatar: string;
  rating: number;
  reviewCount: number;
}

interface RecipeCardProps {
  recipe: Recipe;
}

export default function RecipeCard({ recipe }: RecipeCardProps) {
  return (
    <Card className="recipe-card overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 bg-white">
      <div className="relative">
        <img 
          src={recipe.imageUrl} 
          alt={recipe.title} 
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-2 right-2 bg-white rounded-full p-1.5 shadow-sm cursor-pointer">
          <Heart className="h-4 w-4 text-neutral-700" />
        </div>
        <div className="absolute bottom-0 left-0 w-full bg-gradient-to-t from-black/70 to-transparent p-3">
          <div className="flex items-center">
            <img 
              src={recipe.authorAvatar} 
              alt={`${recipe.authorName} avatar`} 
              className="w-8 h-8 rounded-full object-cover border-2 border-white"
            />
            <span className="text-white text-sm ml-2">{recipe.authorName}</span>
          </div>
        </div>
      </div>
      <div className="p-4">
        <h3 className="font-semibold text-lg mb-1">{recipe.title}</h3>
        <div className="flex items-center mb-3">
          <div className="flex items-center text-yellow-500">
            {[1, 2, 3, 4, 5].map((star) => (
              <svg
                key={star}
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill={star <= Math.floor(recipe.rating) ? "currentColor" : (star === Math.ceil(recipe.rating) && star > Math.floor(recipe.rating) ? "url(#half)" : "none")}
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <defs>
                  <linearGradient id="half" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="50%" stopColor="currentColor" stopOpacity="1" />
                    <stop offset="50%" stopColor="currentColor" stopOpacity="0" />
                  </linearGradient>
                </defs>
                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
              </svg>
            ))}
          </div>
          <span className="text-sm text-neutral-600 ml-2">{recipe.rating.toFixed(1)} ({recipe.reviewCount})</span>
        </div>
        <div className="flex justify-between items-center mb-3 text-sm text-neutral-600">
          <div className="flex items-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="mr-1"
            >
              <circle cx="12" cy="12" r="10" />
              <polyline points="12 6 12 12 16 14" />
            </svg>
            <span>{recipe.prepTime} min</span>
          </div>
          <div className="flex items-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="mr-1"
            >
              <path d="M8 2h8l4 10h-6.5l.5-8h-4l.5 8H4L8 2Z" />
              <path d="M12 12v6" />
              <path d="M8 22v-4h8v4" />
            </svg>
            <span>{recipe.calories} cal</span>
          </div>
          <div className="flex items-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="mr-1"
            >
              <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
              <circle cx="9" cy="7" r="4" />
              <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
              <path d="M16 3.13a4 4 0 0 1 0 7.75" />
            </svg>
            <span>{recipe.servings} servings</span>
          </div>
        </div>
        <div className="flex flex-wrap gap-1 mb-4">
          {recipe.cuisine && (
            <Badge variant="cuisine">{recipe.cuisine}</Badge>
          )}
          {recipe.diet && (
            <Badge variant="diet">{recipe.diet}</Badge>
          )}
          {recipe.difficulty && (
            <Badge variant="difficulty">{recipe.difficulty}</Badge>
          )}
        </div>
        <div className="flex justify-between items-center">
          <Link href={`/recipe/${recipe.id}`} className="w-full">
            <button className="w-full bg-primary hover:bg-primary/90 text-white py-2 rounded-md font-medium transition-colors">
              View Recipe
            </button>
          </Link>
        </div>
      </div>
    </Card>
  );
}
