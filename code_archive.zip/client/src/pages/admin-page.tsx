import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { insertIngredientSchema, insertRecipeSchema } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Plus, Trash } from "lucide-react";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

const ingredientFormSchema = insertIngredientSchema.extend({
  name: z.string().min(2, "Name must be at least 2 characters"),
  category: z.string().min(1, "Category is required"),
});

type IngredientFormValues = z.infer<typeof ingredientFormSchema>;

const recipeFormSchema = insertRecipeSchema.omit({ ingredients: true }).extend({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  prepTime: z.coerce.number().min(1, "Prep time must be at least 1 minute"),
  calories: z.coerce.number().optional(),
  servings: z.coerce.number().optional(),
  cuisine: z.string().optional(),
  diet: z.string().optional(),
  difficulty: z.string().optional(),
  instructions: z.string().min(20, "Instructions must be at least 20 characters"),
  imageUrl: z.string().url("Please enter a valid URL").optional().or(z.literal("")),
  authorName: z.string().min(2, "Author name is required"),
  authorAvatar: z.string().url("Please enter a valid URL").optional().or(z.literal("")),
});

type RecipeIngredient = {
  id: number;
  name: string;
  amount: string;
};

type RecipeFormValues = z.infer<typeof recipeFormSchema> & {
  ingredients: RecipeIngredient[];
};

export default function AdminPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("ingredients");
  const [recipeIngredients, setRecipeIngredients] = useState<RecipeIngredient[]>([]);
  const [newIngredientAmount, setNewIngredientAmount] = useState("");
  const [selectedIngredientId, setSelectedIngredientId] = useState<number | null>(null);

  // Get ingredients for dropdown selection
  const { data: ingredients = [] } = useQuery({
    queryKey: ["/api/ingredients"],
    queryFn: async () => {
      const res = await fetch("/api/ingredients");
      if (!res.ok) throw new Error("Failed to fetch ingredients");
      return res.json();
    },
  });

  // Ingredient form
  const ingredientForm = useForm<IngredientFormValues>({
    resolver: zodResolver(ingredientFormSchema),
    defaultValues: {
      name: "",
      category: "",
      imageUrl: "",
      isPopular: false,
    },
  });

  // Add ingredient mutation
  const addIngredientMutation = useMutation({
    mutationFn: async (data: IngredientFormValues) => {
      const res = await apiRequest("POST", "/api/admin/ingredients", data);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to add ingredient");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/ingredients"] });
      toast({
        title: "Ingredient added",
        description: "The ingredient was added successfully",
      });
      ingredientForm.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to add ingredient",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Recipe form
  const recipeForm = useForm<RecipeFormValues>({
    resolver: zodResolver(recipeFormSchema),
    defaultValues: {
      title: "",
      description: "",
      prepTime: 0,
      calories: undefined,
      servings: undefined,
      cuisine: "",
      diet: "",
      difficulty: "Easy",
      instructions: "",
      imageUrl: "",
      authorId: user?.id,
      authorName: user?.username || "",
      authorAvatar: "",
      ingredients: [],
    },
  });

  // Add recipe mutation
  const addRecipeMutation = useMutation({
    mutationFn: async (data: RecipeFormValues & { ingredients: RecipeIngredient[] }) => {
      const recipeData = {
        ...data,
        authorId: user?.id,
        ingredients: recipeIngredients,
      };
      
      const res = await apiRequest("POST", "/api/admin/recipes", recipeData);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to add recipe");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recipes"] });
      toast({
        title: "Recipe added",
        description: "The recipe was added successfully",
      });
      recipeForm.reset();
      setRecipeIngredients([]);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to add recipe",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleIngredientSubmit = (values: IngredientFormValues) => {
    addIngredientMutation.mutate(values);
  };

  const handleRecipeSubmit = (values: RecipeFormValues) => {
    if (recipeIngredients.length === 0) {
      toast({
        title: "Ingredients required",
        description: "Please add at least one ingredient to the recipe",
        variant: "destructive",
      });
      return;
    }
    
    addRecipeMutation.mutate({
      ...values,
      ingredients: recipeIngredients,
    });
  };

  const addIngredientToRecipe = () => {
    if (!selectedIngredientId || !newIngredientAmount) {
      toast({
        title: "Ingredient information required",
        description: "Please select an ingredient and specify an amount",
        variant: "destructive",
      });
      return;
    }

    const selectedIngredient = ingredients.find(
      (ing: { id: number }) => ing.id === selectedIngredientId
    );

    if (!selectedIngredient) return;

    setRecipeIngredients([
      ...recipeIngredients,
      {
        id: selectedIngredient.id,
        name: selectedIngredient.name,
        amount: newIngredientAmount,
      },
    ]);

    setSelectedIngredientId(null);
    setNewIngredientAmount("");
  };

  const removeIngredientFromRecipe = (index: number) => {
    setRecipeIngredients(recipeIngredients.filter((_, i) => i !== index));
  };

  // List of common ingredient categories
  const commonCategories = [
    "Proteins",
    "Vegetables",
    "Fruits",
    "Grains",
    "Dairy",
    "Herbs",
    "Spices",
    "Condiments",
  ];

  return (
    <div className="container mx-auto py-10">
      <h1 className="text-3xl font-bold mb-6">Admin Dashboard</h1>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="mb-8">
          <TabsTrigger value="ingredients">Manage Ingredients</TabsTrigger>
          <TabsTrigger value="recipes">Manage Recipes</TabsTrigger>
        </TabsList>
        
        <TabsContent value="ingredients">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h2 className="text-2xl font-bold mb-4">Add New Ingredient</h2>
              <Form {...ingredientForm}>
                <form onSubmit={ingredientForm.handleSubmit(handleIngredientSubmit)} className="space-y-6">
                  <FormField
                    control={ingredientForm.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Ingredient name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={ingredientForm.control}
                    name="category"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Category</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a category" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {commonCategories.map((category) => (
                              <SelectItem key={category} value={category}>
                                {category}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={ingredientForm.control}
                    name="imageUrl"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Image URL</FormLabel>
                        <FormControl>
                          <Input placeholder="https://example.com/image.jpg" {...field} />
                        </FormControl>
                        <FormDescription>
                          Link to an image of the ingredient
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={ingredientForm.control}
                    name="isPopular"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Popular Ingredient</FormLabel>
                          <FormDescription>
                            Mark this ingredient as popular to show it at the top of the sidebar
                          </FormDescription>
                        </div>
                      </FormItem>
                    )}
                  />
                  
                  <Button 
                    type="submit"
                    disabled={addIngredientMutation.isPending}
                  >
                    {addIngredientMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Adding...
                      </>
                    ) : (
                      "Add Ingredient"
                    )}
                  </Button>
                </form>
              </Form>
            </div>
            
            <div>
              <h2 className="text-2xl font-bold mb-4">Existing Ingredients</h2>
              <div className="border rounded-lg overflow-hidden">
                <div className="max-h-[500px] overflow-y-auto">
                  <table className="w-full">
                    <thead className="bg-muted sticky top-0">
                      <tr>
                        <th className="text-left p-3">Name</th>
                        <th className="text-left p-3">Category</th>
                        <th className="text-left p-3">Popular</th>
                      </tr>
                    </thead>
                    <tbody>
                      {ingredients.map((ingredient: any) => (
                        <tr key={ingredient.id} className="border-t">
                          <td className="p-3">{ingredient.name}</td>
                          <td className="p-3">{ingredient.category}</td>
                          <td className="p-3">
                            {ingredient.isPopular ? "Yes" : "No"}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="recipes">
          <div className="grid grid-cols-1 gap-8">
            <div>
              <h2 className="text-2xl font-bold mb-4">Add New Recipe</h2>
              <Form {...recipeForm}>
                <form onSubmit={recipeForm.handleSubmit(handleRecipeSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-6">
                      <FormField
                        control={recipeForm.control}
                        name="title"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Title</FormLabel>
                            <FormControl>
                              <Input placeholder="Recipe title" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={recipeForm.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Description</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Brief description of the recipe" 
                                className="resize-none" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={recipeForm.control}
                          name="prepTime"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Prep Time (minutes)</FormLabel>
                              <FormControl>
                                <Input type="number" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={recipeForm.control}
                          name="servings"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Servings</FormLabel>
                              <FormControl>
                                <Input type="number" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={recipeForm.control}
                          name="cuisine"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Cuisine</FormLabel>
                              <FormControl>
                                <Input placeholder="e.g. Italian" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={recipeForm.control}
                          name="diet"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Diet</FormLabel>
                              <FormControl>
                                <Input placeholder="e.g. Vegetarian" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <FormField
                        control={recipeForm.control}
                        name="difficulty"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Difficulty</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select difficulty" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="Easy">Easy</SelectItem>
                                <SelectItem value="Medium">Medium</SelectItem>
                                <SelectItem value="Hard">Hard</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={recipeForm.control}
                        name="imageUrl"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Image URL</FormLabel>
                            <FormControl>
                              <Input placeholder="https://example.com/recipe.jpg" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="space-y-6">
                      <FormField
                        control={recipeForm.control}
                        name="instructions"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Instructions</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Step-by-step instructions" 
                                className="min-h-[150px]" 
                                {...field} 
                              />
                            </FormControl>
                            <FormDescription>
                              Use numbered steps (e.g. 1. Preheat oven...)
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div>
                        <Label>Ingredients</Label>
                        <div className="border rounded-lg p-4 mt-2 space-y-4">
                          <div className="flex items-end gap-2">
                            <div className="flex-1">
                              <Label htmlFor="ingredient">Ingredient</Label>
                              <Select
                                value={selectedIngredientId?.toString() || ""}
                                onValueChange={(value) => setSelectedIngredientId(Number(value))}
                              >
                                <SelectTrigger>
                                  <SelectValue placeholder="Select ingredient" />
                                </SelectTrigger>
                                <SelectContent>
                                  {ingredients.map((ingredient: any) => (
                                    <SelectItem 
                                      key={ingredient.id} 
                                      value={ingredient.id.toString()}
                                    >
                                      {ingredient.name}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>
                            
                            <div className="flex-1">
                              <Label htmlFor="amount">Amount</Label>
                              <Input
                                id="amount"
                                placeholder="e.g. 2 tbsp"
                                value={newIngredientAmount}
                                onChange={(e) => setNewIngredientAmount(e.target.value)}
                              />
                            </div>
                            
                            <Button 
                              type="button" 
                              variant="secondary" 
                              size="icon"
                              onClick={addIngredientToRecipe}
                            >
                              <Plus className="h-4 w-4" />
                            </Button>
                          </div>
                          
                          <div>
                            <Label>Current Ingredients</Label>
                            {recipeIngredients.length === 0 ? (
                              <p className="text-muted-foreground text-sm mt-2">
                                No ingredients added yet
                              </p>
                            ) : (
                              <ul className="mt-2 space-y-2">
                                {recipeIngredients.map((ingredient, index) => (
                                  <li 
                                    key={index} 
                                    className="flex items-center justify-between bg-muted p-2 rounded"
                                  >
                                    <span>
                                      {ingredient.name} - {ingredient.amount}
                                    </span>
                                    <Button
                                      type="button"
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => removeIngredientFromRecipe(index)}
                                    >
                                      <Trash className="h-4 w-4" />
                                    </Button>
                                  </li>
                                ))}
                              </ul>
                            )}
                          </div>
                        </div>
                      </div>
                      
                      <FormField
                        control={recipeForm.control}
                        name="authorName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Author Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Recipe author" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={recipeForm.control}
                        name="authorAvatar"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Author Avatar URL</FormLabel>
                            <FormControl>
                              <Input placeholder="https://example.com/avatar.jpg" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full"
                    disabled={addRecipeMutation.isPending}
                  >
                    {addRecipeMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Adding Recipe...
                      </>
                    ) : (
                      "Add Recipe"
                    )}
                  </Button>
                </form>
              </Form>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}