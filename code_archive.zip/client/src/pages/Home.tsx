import { useState } from "react";
import IngredientSidebar from "@/components/IngredientSidebar";
import MainContent from "@/components/MainContent";

export default function Home() {
  const [selectedIngredients, setSelectedIngredients] = useState<number[]>([]);

  // Toggle ingredient selection
  const handleIngredientToggle = (id: number) => {
    setSelectedIngredients(prev => 
      prev.includes(id)
        ? prev.filter(ingredientId => ingredientId !== id)
        : [...prev, id]
    );
  };

  // Clear a specific ingredient
  const handleClearIngredient = (id: number) => {
    setSelectedIngredients(prev => prev.filter(ingredientId => ingredientId !== id));
  };

  // Clear all selected ingredients
  const handleClearAllIngredients = () => {
    setSelectedIngredients([]);
  };

  return (
    <div className="min-h-screen bg-neutral-100">
      {/* Header */}
      <header className="bg-white shadow-sm fixed top-0 w-full z-30">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center">
              <a href="/" className="flex items-center">
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  width="24" 
                  height="24" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  className="text-primary mr-2"
                >
                  <path d="M15 11h.01" />
                  <path d="M11 15h.01" />
                  <path d="M16 16h.01" />
                  <path d="m2 16 20 6-6-20A30 30 0 0 0 2 16" />
                  <path d="M5.71 17.11a17.04 17.04 0 0 1 11.4-11.4" />
                </svg>
                <h1 className="text-xl font-semibold">RecipeFinder</h1>
              </a>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-8">
              <a href="/" className="text-neutral-700 hover:text-primary font-medium">Home</a>
            </nav>

            {/* Authentication */}
            <div className="flex items-center space-x-4">
              <button className="hidden md:block px-4 py-2 rounded-md text-accent border border-accent hover:bg-accent hover:text-white transition-colors font-medium">
                Log In
              </button>
              <button className="hidden md:block px-4 py-2 rounded-md bg-primary text-white hover:bg-opacity-90 transition-colors font-medium">
                Sign Up
              </button>
              <button className="p-2 rounded-full bg-neutral-100 text-neutral-700 relative">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
                  <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
                </svg>
                <span className="absolute top-0 right-0 h-2 w-2 bg-primary rounded-full"></span>
              </button>
              <button className="md:hidden">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-6 w-6 text-neutral-700"
                >
                  <line x1="4" x2="20" y1="12" y2="12" />
                  <line x1="4" x2="20" y1="6" y2="6" />
                  <line x1="4" x2="20" y1="18" y2="18" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="mt-16 min-h-screen flex">
        {/* Ingredient Sidebar */}
        <IngredientSidebar 
          selectedIngredients={selectedIngredients}
          onIngredientToggle={handleIngredientToggle}
        />
        
        {/* Main Content */}
        <MainContent 
          selectedIngredients={selectedIngredients}
          onClearIngredient={handleClearIngredient}
          onClearAllIngredients={handleClearAllIngredients}
        />
      </main>

      {/* Mobile Bottom Navigation */}
      <nav className="md:hidden fixed bottom-0 w-full bg-white shadow-md px-6 py-3 z-30 border-t border-neutral-200">
        <div className="flex justify-between items-center">
          <a href="/" className="flex flex-col items-center text-primary">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-5 w-5"
            >
              <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
              <polyline points="9 22 9 12 15 12 15 22" />
            </svg>
            <span className="text-xs mt-1">Home</span>
          </a>
          <a href="#" className="flex flex-col items-center text-neutral-500">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-5 w-5"
            >
              <circle cx="11" cy="11" r="8" />
              <path d="m21 21-4.3-4.3" />
            </svg>
            <span className="text-xs mt-1">Search</span>
          </a>
          <a href="#" className="flex flex-col items-center text-neutral-500">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-5 w-5"
            >
              <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
              <circle cx="12" cy="7" r="4" />
            </svg>
            <span className="text-xs mt-1">Profile</span>
          </a>
        </div>
      </nav>
    </div>
  );
}
