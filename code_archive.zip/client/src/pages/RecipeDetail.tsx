import { useRoute } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Clock, Flame, Users, ChevronLeft, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function RecipeDetail() {
  const [match, params] = useRoute("/recipe/:id");
  const recipeId = params?.id;

  const { data: recipe, isLoading } = useQuery({
    queryKey: [`/api/recipes/${recipeId}`],
    enabled: !!recipeId,
  });

  if (isLoading) {
    return <RecipeDetailSkeleton />;
  }

  if (!recipe) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-neutral-100">
        <div className="bg-white p-8 rounded-lg shadow-sm max-w-md text-center">
          <h2 className="text-2xl font-semibold mb-4">Recipe Not Found</h2>
          <p className="text-neutral-600 mb-6">The recipe you are looking for does not exist or has been removed.</p>
          <Link href="/">
            <Button className="bg-primary hover:bg-primary/90">Back to Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-100 pt-16">
      {/* Header */}
      <header className="bg-white shadow-sm fixed top-0 w-full z-30">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center">
              <a href="/" className="flex items-center">
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  width="24" 
                  height="24" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  className="text-primary mr-2"
                >
                  <path d="M15 11h.01" />
                  <path d="M11 15h.01" />
                  <path d="M16 16h.01" />
                  <path d="m2 16 20 6-6-20A30 30 0 0 0 2 16" />
                  <path d="M5.71 17.11a17.04 17.04 0 0 1 11.4-11.4" />
                </svg>
                <h1 className="text-xl font-semibold">RecipeFinder</h1>
              </a>
            </div>

            {/* Authentication */}
            <div className="flex items-center space-x-4">
              <button className="hidden md:block px-4 py-2 rounded-md text-accent border border-accent hover:bg-accent hover:text-white transition-colors font-medium">
                Log In
              </button>
              <button className="hidden md:block px-4 py-2 rounded-md bg-primary text-white hover:bg-opacity-90 transition-colors font-medium">
                Sign Up
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <Link href="/">
            <Button variant="ghost" className="mb-4 pl-0">
              <ChevronLeft className="mr-1 h-4 w-4" />
              Back to Recipes
            </Button>
          </Link>
        </div>

        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          {/* Recipe hero image */}
          <div className="relative h-80 md:h-96">
            <img 
              src={recipe.imageUrl} 
              alt={recipe.title} 
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
            
            <div className="absolute bottom-0 left-0 p-6 w-full">
              <div className="flex items-center mb-2">
                <img 
                  src={recipe.authorAvatar} 
                  alt={`${recipe.authorName} avatar`} 
                  className="w-10 h-10 rounded-full object-cover border-2 border-white"
                />
                <span className="text-white text-sm ml-2">{recipe.authorName}</span>
              </div>
              <h1 className="text-3xl font-bold text-white mb-2">{recipe.title}</h1>
              <div className="flex flex-wrap gap-2 mb-3">
                {recipe.cuisine && (
                  <Badge variant="cuisine">{recipe.cuisine}</Badge>
                )}
                {recipe.diet && (
                  <Badge variant="diet">{recipe.diet}</Badge>
                )}
                {recipe.difficulty && (
                  <Badge variant="difficulty">{recipe.difficulty}</Badge>
                )}
              </div>
              <div className="flex items-center text-white">
                <div className="flex items-center text-yellow-400 mr-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <svg
                      key={star}
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill={star <= Math.floor(recipe.rating) ? "currentColor" : (star === Math.ceil(recipe.rating) && star > Math.floor(recipe.rating) ? "url(#half)" : "none")}
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <defs>
                        <linearGradient id="half" x1="0%" y1="0%" x2="100%" y2="0%">
                          <stop offset="50%" stopColor="currentColor" stopOpacity="1" />
                          <stop offset="50%" stopColor="currentColor" stopOpacity="0" />
                        </linearGradient>
                      </defs>
                      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
                    </svg>
                  ))}
                </div>
                <span className="text-sm">{recipe.rating.toFixed(1)} ({recipe.reviewCount} reviews)</span>
              </div>
            </div>
            
            <Button className="absolute top-4 right-4 bg-white/80 text-primary hover:bg-white rounded-full p-2 shadow-sm h-auto">
              <Heart className="h-5 w-5" />
            </Button>
          </div>
          
          {/* Recipe details */}
          <div className="p-6">
            <div className="flex flex-wrap justify-between mb-8 gap-4">
              <div className="flex items-center">
                <Clock className="h-5 w-5 text-primary mr-2" />
                <div>
                  <p className="text-sm text-neutral-500">Prep Time</p>
                  <p className="font-medium">{recipe.prepTime} min</p>
                </div>
              </div>
              <div className="flex items-center">
                <Flame className="h-5 w-5 text-primary mr-2" />
                <div>
                  <p className="text-sm text-neutral-500">Calories</p>
                  <p className="font-medium">{recipe.calories} cal</p>
                </div>
              </div>
              <div className="flex items-center">
                <Users className="h-5 w-5 text-primary mr-2" />
                <div>
                  <p className="text-sm text-neutral-500">Servings</p>
                  <p className="font-medium">{recipe.servings}</p>
                </div>
              </div>
            </div>
            
            <div className="mb-8">
              <h2 className="text-xl font-semibold mb-4">Description</h2>
              <p className="text-neutral-700">{recipe.description}</p>
            </div>
            
            <div className="mb-8">
              <h2 className="text-xl font-semibold mb-4">Ingredients</h2>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {recipe.ingredients.map((ingredient: any, index: number) => (
                  <li key={index} className="flex items-start">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-5 w-5 text-secondary mr-2 mt-0.5"
                    >
                      <polyline points="9 11 12 14 22 4" />
                      <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" />
                    </svg>
                    <span className="text-neutral-800">{ingredient.amount} {ingredient.name}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            <div>
              <h2 className="text-xl font-semibold mb-4">Instructions</h2>
              <div className="prose prose-neutral max-w-none">
                {recipe.instructions.split("\n").map((step: string, index: number) => {
                  if (!step.trim()) return null;
                  return (
                    <div key={index} className="mb-4 flex">
                      <div className="mr-4 flex-shrink-0">
                        <div className="bg-primary/10 text-primary font-medium h-7 w-7 rounded-full flex items-center justify-center">
                          {index + 1}
                        </div>
                      </div>
                      <p className="text-neutral-700">{step.replace(/^\d+\.\s/, '')}</p>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function RecipeDetailSkeleton() {
  return (
    <div className="min-h-screen bg-neutral-100 pt-16">
      {/* Header placeholder */}
      <header className="bg-white shadow-sm fixed top-0 w-full z-30 h-16"></header>

      <div className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <Skeleton className="h-10 w-32" />
        </div>

        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          {/* Hero image skeleton */}
          <Skeleton className="w-full h-80 md:h-96" />
          
          {/* Recipe details skeleton */}
          <div className="p-6">
            <div className="flex flex-wrap justify-between mb-8 gap-4">
              {[1, 2, 3].map(i => (
                <div key={i} className="flex items-center">
                  <Skeleton className="h-8 w-8 mr-2 rounded-full" />
                  <div>
                    <Skeleton className="h-4 w-20 mb-1" />
                    <Skeleton className="h-5 w-16" />
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mb-8">
              <Skeleton className="h-7 w-40 mb-4" />
              <Skeleton className="h-4 w-full mb-2" />
              <Skeleton className="h-4 w-full mb-2" />
              <Skeleton className="h-4 w-3/4" />
            </div>
            
            <div className="mb-8">
              <Skeleton className="h-7 w-40 mb-4" />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {Array(8).fill(0).map((_, i) => (
                  <Skeleton key={i} className="h-6 w-full" />
                ))}
              </div>
            </div>
            
            <div>
              <Skeleton className="h-7 w-40 mb-4" />
              {Array(5).fill(0).map((_, i) => (
                <div key={i} className="mb-4 flex">
                  <Skeleton className="h-7 w-7 rounded-full mr-4" />
                  <Skeleton className="h-6 w-full" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
