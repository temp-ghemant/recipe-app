import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";
import { Redirect, Route, RouteProps } from "wouter";

interface ProtectedRouteProps extends RouteProps {
  requireAdmin?: boolean;
}

export function ProtectedRoute({
  path,
  requireAdmin = false,
  children,
}: ProtectedRouteProps) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <Route path={path}>
        <div className="flex items-center justify-center min-h-screen">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </Route>
    );
  }

  if (!user) {
    return (
      <Route path={path}>
        <Redirect to="/auth" />
      </Route>
    );
  }

  if (requireAdmin && !user.isAdmin) {
    return (
      <Route path={path}>
        <div className="flex items-center justify-center min-h-screen flex-col gap-4">
          <h1 className="text-2xl font-bold">Unauthorized</h1>
          <p>You do not have admin privileges to access this page.</p>
          <Redirect to="/" />
        </div>
      </Route>
    );
  }

  return <Route path={path}>{children}</Route>;
}